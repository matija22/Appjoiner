<?php
$db = new PDO('mysql:host=localhost;dbname=apps','root','');
?>