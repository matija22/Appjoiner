$(document).ready( function() {
	
	jQuery.expr[':'].contains = function(a, i, m) {
  return jQuery(a).text().toUpperCase()
      .indexOf(m[3].toUpperCase()) >= 0;
};
	
$('.search-input').keyup(function() {
	
	
  var keyword = $(this).val().toLowerCase(),
      cont = $('.row');
  if(keyword.length > 0) {
	$('.col-md-4').addClass('skriveno');
 
	  cont.find( 'span:contains("' + keyword + '")' ).parents('.col-md-4').removeClass('skriveno'); 
  } else {
	  $('.col-md-4').removeClass('skriveno');
	  
  }
  
});
});

