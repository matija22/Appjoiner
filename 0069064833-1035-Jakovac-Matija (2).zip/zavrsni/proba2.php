<?php
include "config.php";
session_start();
if(isset($_POST['prob']))  
 {
	 $ime = $_POST['key'];
	 $_SESSION['key'] = $ime;
	 
 }
 if (isset($_SESSION['key']) ) {

 if(isset($_POST["btn_zip"]))  
 {  
      $output = '';  
      if($_FILES['zip_file']['name'] != '')  
      {  
           $file_name = $_FILES['zip_file']['name'];  
           $array = explode(".", $file_name);  
           $name = $array[0];  
           $ext = $array[1];  
           if($ext == 'zip')  
           {  
                $path = 'upload/';  
                $location = $path . $file_name;  
                if(move_uploaded_file($_FILES['zip_file']['tmp_name'], $location))  
                {  
                     $zip = new ZipArchive;  
                     if($zip->open($location))  
                     {  
                          $zip->extractTo($path.$_SESSION['key']);  
                          $zip->close();  
                     }  
                     
                     unlink($location);    
                }  
           }  
      } 
	  
	  $dir = "upload/".$_SESSION['key'];


// Open a directory, and read its contents
function rdir($dir) { 
include "config.php";
   if (is_dir($dir)) { 
     $objects = scandir($dir); 
     foreach ($objects as $object) { 
       if ($object != "." && $object != "..") { 
         if (is_dir($dir."/".$object)){
			
           rdir($dir."/".$object);
		 }
         else{
			  $dir2=$dir."/".$object;
		  $add = $db->prepare("insert into ".$_SESSION['key']." values('',?,'0','$dir2')");
		  $add->bindParam(1,$object);
		  $add->execute();
					
		   		} 
       } 
     } 
   } 
 }
 rdir($dir);
header("location:proba2.php");
	}
 }
 if(isset($_GET['hapus'])){
			$tmp = $_GET['hapus'];
			unlink($tmp);
				$hps = $db->prepare("delete from ".$_SESSION['key']." where path='$tmp'");
				if($hps->execute()){
				}else{
				}
				$hps = $db->prepare("delete from ".$_SESSION['key']." where path='$tmp'");
				if($hps->execute()){
				}else{
				}
			header("location:proba2.php");
}
 if(isset($_POST['check'])){
			$hol=$_POST['izvr'];
			$ime = $_SESSION['key'];
			$stmt = $db->prepare("update $ime set flag='0'");
			$stmt ->execute();
			$stm = $db->prepare("update $ime set flag='1' where firstname='$hol'");
			$stm ->execute();
			 header("location:proba2.php");
		}
if(isset($_POST['sub_url'])){
	$conn = mysqli_connect("localhost","root","","apps");
			$url=$_POST['text_url'];
			$ime = $_SESSION['key'];
			$safe_url = mysqli_real_escape_string($conn, $url);
		$stm = $db->prepare("insert into $ime values('','$safe_url','1','$safe_url')");
		$stm ->execute();
		
		}
		if (isset($_SESSION['uname']) ) { ?>
           <div class="container" style="width:500px;"> 
			
                <form method="post" enctype="multipart/form-data">  
                     <label>Odaberi zip file</label>  
                     <input type="file" name="zip_file" />  
                     <br />  
                     <input type="submit" name="btn_zip" class="btn btn-info" value="Upload" />  
                </form> 
				
                <br />
			
				<form method="post">  
                     <label>Zalijepi URL</label>  
                     <input type="text" name="text_url" />  
                     <br />  
                     <input type="submit" name="sub_url" class="btn btn-info" value="Upload" />  
                </form> 
           </div>
		<?php
		
}

			$dir = "upload/".$_SESSION['key'];
			function rddir($dir) { 
			$ime = $_SESSION['key'];
   if (is_dir($dir)) { 
     $objects = scandir($dir); 
     foreach ($objects as $object) { 
       if ($object != "." && $object != "..") { 
         if (is_dir($dir."/".$object))
           rddir($dir."/".$object);
         else{?>
		  <div class="col-xs-6 col-md-3">
					<div class="butt-cont animated bounceInDown">
						<form action="<?php echo $dir."/".$object ?>" target="_blank">
							<button class="button2"type="submit"><span><p><?php echo $object ?></p></span></button>
						</form>
						<?php if (isset($_SESSION['uname']) ) { ?>
						<div>
						<p><a href="?hapus=<?php echo $dir."/".$object?>" onclick="return confirm('Želite izbrisati datoteku <?php echo $object ?>?')" class="deletebtn" role="button"></a></p>
							
								<form method="post">
								<input type="hidden" name="izvr" value="<?php echo $object ?>" />
								<input type="checkbox" name="izvrs">
								<input type="submit" name="check">
								</form>
							
						</div>
						<?php } ?>
						<br>
					</div>
					</div>
					<?php
		   		} 
       } 
     } 
   } 
 }
 rddir($dir);
 $ime = $_SESSION['key'];
 $conn = mysqli_connect("localhost","root","","apps");
$check2 = mysqli_query($conn,"SELECT * FROM $ime");
$check = "SELECT * FROM $ime";
		
		$izvrs = $conn->query($check);
		$red = mysqli_fetch_row($izvrs);
		if(mysqli_num_rows($check2) <= 4 && mysqli_num_rows($check2)>0){?>
	 <div class="col-xs-6 col-md-3">
					<div class="butt-cont animated bounceInDown">
						<form action="<?php echo $red[1] ?>" target="_blank">
							<button class="button2"type="submit"><span><p><?php echo $red[1] ?></p></span></button>
						</form>
						<?php if (isset($_SESSION['uname']) ) { ?>
						<div>
						<p><a href="?hapus=<?php echo $red[1]?>" onclick="return confirm('Želite izbrisati datoteku <?php echo $red[1] ?>?')" class="deletebtn" role="button"></a></p>
						</div>
						<?php } ?>
						<br>
					</div>
					</div>
					<?php
}
 ?>
<!DOCTYPE html>  
 <html>  
      <head>  
		   <title><?php echo $_SESSION['key']; ?></title>
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
           <link rel="stylesheet" type="text/css" href="novo.css">
		   <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
           <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
      </head>  
      <body>  
					
			
      </body>  
 </html>