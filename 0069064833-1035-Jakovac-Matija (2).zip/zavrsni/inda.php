<?php session_start(); ?>
<!DOCTYPE html>
<html>
<head>
<title>zavapp</title>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" href="novo.css">
<link rel="stylesheet" type="text/css" href="animate.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script src="http://code.jquery.com/ui/1.9.2/jquery-ui.js"></script>
<script type="text/javascript" src="test.js"></script>
</head>

<!-- Top menu on small screens -->

<body class="w3-light-gray">

    <p><br/><br/></p>
	
    <p><br/><br/></p>
<!-- Sidebar/menu -->
	<nav class="w3-sidebar w3-bar-block w3-black w3-animate-right w3-top w3-text-light-grey w3-large" style="z-index:3;width:250px;font-weight:bold;display:none;right:0;" id="mySidebar">
		<a href="javascript:void()" onclick="w3_close()" class="w3-bar-item w3-button w3-center w3-padding-32">ZATVORI</a> 
		<a href="#" onclick="w3_close()" class="w3-bar-item w3-button w3-center w3-padding-16">APLIKACIJE</a> 
		<a href="#bar2" onclick="w3_close()" class="w3-bar-item w3-button w3-center w3-padding-16"> PRIJAVA</a> 
		<?php if (isset($_SESSION['uname']) ) {?>
		<div class="button1"></div> 
		<a href="logout.php" onclick="w3_close()" class="w3-bar-item w3-button w3-center w3-padding-32"> ODJAVA</a>
		<?php } ?>
	</nav>
	<!-- zaglavlje  -->
	<header class="w3-container w3-top w3-white w3-xlarge w3-padding-16">
		<span class="w3-left w3-padding">AppJoiner </span>
		<a href="javascript:void(0)" class="w3-right w3-button w3-white" onclick="w3_open()">☰</a>
		<div class="pomak"><form>
		<input class="search-input inp" type="search" placeholder="Search">
		</form></div>
	</header>
	
	<!-- Overlay effect when opening sidebar on small screens -->
	<div class="w3-overlay w3-animate-opacity" onclick="w3_close()" style="cursor:pointer" title="close side menu" id="myOverlay"></div>
	<!-- aplikacija, prvi container -->
	<div class="container">
	<!-- php kod za logiranje -->
	<?php
		$db1 = mysqli_connect("localhost","root","","apps");


		if(isset($_POST['sub']))
		{
			 $uname = mysqli_real_escape_string($db1,$_POST['uname']);
			 $pass = mysqli_real_escape_string($db1,$_POST['pass']);
			 $pass = md5($pass);


			 
			 $check = mysqli_query($db1,"SELECT * FROM `user` WHERE `uname` = '$uname' AND `pass` = '$pass'");
			 if(mysqli_num_rows($check) >= 1){
			  $_SESSION['uname'] = $uname;
			  $_SESSION['password'] = $pass;
			  header("location:inda.php");
			  exit();
			 }else{
				?>
			 
				<div class="alert alert-warning alert-dismissible" role="alert">
				<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<strong>Pozor!</strong> Pogrešna prijava, pokušajte ponovno!
				</div>
					<?php
				}
		}
		
		?>
	<!-- php kod za upload datoteke -->
	<?php
	include "config.php";
	if(isset($_GET['hap'])){
			$tabl = $_GET['hap'];
			$dir = "upload/".$tabl;
			function rrmdir($dir) { 
			   if (is_dir($dir)) { 
				 $objects = scandir($dir); 
				 foreach ($objects as $object) { 
				   if ($object != "." && $object != "..") { 
					 if (is_dir($dir."/".$object))
					   rrmdir($dir."/".$object);
					 else
					   unlink($dir."/".$object); 
				   } 
				 }
				 rmdir($dir); 
			   } 
			 }
			rrmdir($dir);

			
				$hps = $db->prepare("drop table $tabl");
				if($hps->execute()){
				}else{
				}
			
			header("location:inda.php");
		}
		?>
	<?php
				include "config.php";
				$conn = mysqli_connect("localhost","root","","apps");
 if(isset($_POST["fsub"]))  
 {
	 $conn = mysqli_connect("localhost","root","","apps");
	 $ime = $_POST['fname'];
	 mkdir("upload/".$ime);
	
	
		$sql = "CREATE TABLE ".$_POST['fname']." (
	id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY, 
	firstname VARCHAR(100) NOT NULL,flag VARCHAR(30) NOT NULL,path VARCHAR(100) NOT NULL
	)";
if ($conn->query($sql) === TRUE) {
    echo "Tablica uspješno kreirana";
} else {
    echo "Greška: " . $conn->error;
}
header("location:inda.php");
 }
 
		
	?>	
	<!-- brisanje datoteka -->
	<div class="row">
		 <?php
		 



		 $sql = "show tables";
				$result = $conn->query($sql);
				while($row = mysqli_fetch_row($result)){
					if($row[0]=='user'){}
					else{
						$dir = "upload/";
						$ime = $row[0];
						$check = "SELECT * FROM $ime WHERE flag = '1'";
						
						$izvrs = $conn->query($check);
						$red = mysqli_fetch_row($izvrs);
						
						$check2 = mysqli_query($conn,"SELECT * FROM $ime");
		
		
		?>
		<div class="col-sm-6 col-md-4">
		<div class="thumbnail">
		
      <form action="proba2.php" target="_blank" method="post">
							<input type="hidden" name="key" value="<?php echo $row[0] ?>" />
							<button type="submit" name="prob" class="button3"><span><p><?php echo $row[0] ?></p></span></button>
					</form>
		
		<?php
		if(mysqli_num_rows($check2) > 1){
		
		?>
      <div class="caption">
        <a href='<?php echo $red[3]?>' target="_blank"><h3><p><?php echo $red[1]?></p></h3></a>
        <p>...</p>
		</div>
		<?php } else{ ?>
		<div class="caption">
        <a href="<?php echo $red[3]?>" target="_blank"><h3><p><?php echo $red[1]?></p></h3></a>
        <p>...</p>
		</div>
		<?php }?>
    </div>
				 
						<?php if (isset($_SESSION['uname']) ) { ?>
					<div>
							<p><a href="?hap=<?php echo $row[0] ?>" onclick="return confirm('Želite izbrisati aplikaciju <?php echo $row[0] ?>?')"class="deletebtn" role="button"></a></p>
						</div>
				<?php } ?>
						
					</div>
		<?php
				}
				}?>
				<?php if (isset($_SESSION['uname']) ) { ?>
					
				
				<div class="col-sm-6 col-md-4">
				<button onclick="document.getElementById('id01').style.display='block'" class="button4 w3-light-gray"><div class="place">+</div></button>
				

					<div id="id01" class="modal">
					  
					  <form class="modal-content animate" action="" method="post">
						<div class="imgcontainer">
						  <span onclick="document.getElementById('id01').style.display='none'" class="close1" title="Zatvori">&times;</span>
						  
						</div>

						<div class="cont">
						  <label class="boja">Upiši ime foldera<p class="glyphicon glyphicon-question-sign" role="button" title="xampp/htdocs/upload/"></p></label>
						  <input type="text" placeholder="Upiši ime foldera" name="fname" class="boja" required>

						  <button class="but"type="submit" name="fsub">Napravi</button>
						</div>

						<div class="cont" style="background-color:#f1f1f1">
							<button type="button" onclick="document.getElementById('id01').style.display='none'" class="cancelbtn1 tekst">Cancel</button>
						</div>
					  </form>
					</div>
										
				</div>
				<?php } else{?>
				<div class="col-sm-6 col-md-4">
				<button class="button4 w3-light-gray disabled" title="Potrebna je prijava"><div class="place">+</div></button>
				</div>
				
				<?php } ?>
				
		
		</div>
	</div>
	<!-- container za admina -->
		<div class="w3-container w3-gray w3-center w3-text-light-grey w3-padding-32" id="bar2">
			<div class="w3-content w3-justify w3-center" style="max-width:600px">
			
				
							<!-- zabrana logiranja ukoliko smo već logirani -->
				<?php if (isset($_SESSION['uname']) ) {
				?>
				
				<h3>Login</h3>
				<button style="width:auto;" class="button1 disabled"></button>
				
				<?php } else{
				?>
				<!-- container za logiranje -->
				
					<h3>Login</h3>
					<button onclick="document.getElementById('id02').style.display='block'" style="width:auto;" class="button1"></button>

					<div id="id02" class="modal">
					  
					  <form class="modal-content animate" action="" method="post">
						<div class="imgcontainer">
						  <span onclick="document.getElementById('id02').style.display='none'" class="close1" title="Zatvori">&times;</span>
						  
						</div>

						<div class="cont">
						  <label class="boja">Korisničko ime</label>
						  <input type="text" placeholder="Upiši korisničko ime" name="uname" class="boja" required>

						  <label class="boja">Lozinka</label>
						  <input type="password" placeholder="Upiši lozinku" name="pass" class="boja" required>
							
						  <button class="but"type="submit" name="sub">Login</button>
						</div>

						<div class="cont" style="background-color:#f1f1f1">
							<button type="button" onclick="document.getElementById('id02').style.display='none'" class="cancelbtn1 tekst">Cancel</button>
						</div>
					  </form>
					</div>
				
				<?php }
				?>
				
				
				<script>
				// Get the modal
				var modal = document.getElementById('id01');
				var modal2 = document.getElementById('id02');
				// When the user clicks anywhere outside of the modal, close it
				window.onclick = function(event) {
					if (event.target == modal) {
						modal.style.display = "none";
					}
					if (event.target == modal2) {
						modal2.style.display = "none";
					}
				}
				</script>
			</div>
		</div>
	
	<script>
	// Script to open and close sidebar
	function w3_open() {
		document.getElementById("mySidebar").style.display = "block";
		document.getElementById("myOverlay").style.display = "block";	
	}

	function w3_close() {
		document.getElementById("mySidebar").style.display = "none";
		document.getElementById("myOverlay").style.display = "none";
	}


	</script>
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</body>
</html>
